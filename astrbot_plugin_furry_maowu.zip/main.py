"""AstrBot 插件：毛毛星期五（兽云祭毛图 / 兽兽插画）。

基于兽云祭（cloud.foxtail.cn）官方 API 获取随机或指定的 Furry 毛图 / 兽兽插画。

支持的指令：
  /随机毛五        - 随机获取一张兽图、毛毛照片或插画
  /来只 <ID或名称> - 按数字 SID 或名称获取指定图片
  /来只毛 [名称]   - 随机或按名称获取一张毛毛照片（type=1）
  /来只兽 [名称]   - 随机或按名称获取一张兽兽插画（type=2）
"""

from __future__ import annotations

import httpx

import astrbot.api.message_components as Comp
from astrbot.api import logger
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Context, Star, register

# 兽云祭 API 基础地址
_API_BASE = "https://cloud.foxtail.cn/api/function"
# 随机 / 按名称查询接口，真实查询参数为 type 与 name
_RANDOM_URL = f"{_API_BASE}/random"
# 拉取指定 SID 图片详情的接口，拼接图片 SID 后返回可直接访问的图片 url
_PICTURES_URL = f"{_API_BASE}/pictures?model=1&picture="
# 单次请求超时时间（秒）
_REQUEST_TIMEOUT = 30.0


class FoxtailClient:
    """兽云祭 API 的轻量异步客户端。

    仅封装本插件需要的「获取图片」相关接口，不涉及账号登录 / 图片上传等能力。
    所有方法在网络异常或 HTTP 状态码异常时都返回 (False, None, 提示)，由上层给出友好回复。
    """

    async def _request_json(
        self, url: str, params: dict | None = None
    ) -> dict | None:
        """发起 GET 请求并返回 JSON；任何网络 / 解析异常都返回 None。

        Args:
            url: 请求 URL。
            params: 可选的查询参数字典，会自动进行 URL 编码。
        """
        try:
            async with httpx.AsyncClient(timeout=_REQUEST_TIMEOUT) as client:
                resp = await client.get(url, params=params)
        except Exception as e:  # noqa: BLE001 - 统一兜底，交由上层转成友好提示
            logger.error(f"兽云祭请求失败: {e}")
            return None
        if resp.status_code != 200:
            logger.error(f"兽云祭请求返回 HTTP {resp.status_code}")
            return None
        try:
            return resp.json()
        except Exception as e:  # noqa: BLE001
            logger.error(f"兽云祭响应解析失败: {e}")
            return None

    async def get_random(
        self,
        pic_type: str = "",
        name: str = "",
    ) -> tuple[bool, dict | None, str]:
        """随机或按名称获取一张图片的元数据（含 SID）。

        Args:
            pic_type: 图片类型，0=设定 1=毛图 2=插画，留空表示全局随机。
            name: 名称关键字，留空表示不按名称筛选。

        Returns:
            (success, picture, message)：picture 为包含 id 的图片对象，失败时 success 为 False。
        """
        # 始终携带 type / name 参数（空值即代表「全局随机 / 不筛选」），与官方接口约定一致。
        data = await self._request_json(
            _RANDOM_URL, params={"type": pic_type, "name": name}
        )
        if data is None:
            return False, None, "请求兽云祭服务失败，请稍后重试"
        code = data.get("code")
        if code == "20900":
            return True, data.get("picture"), "ok"
        if code == "20901":
            return False, None, "当前关键词暂无条件匹配的图片"
        return False, None, str(data.get("msg", "未知错误"))

    async def get_by_sid(self, sid: str) -> tuple[bool, dict | None, str]:
        """根据 SID 拉取图片详情（含可直连的 url）。

        Args:
            sid: 图片的数字 SID。

        Returns:
            (success, detail, message)：detail 含 url / name / id / suggest 字段，失败时 success 为 False。
        """
        data = await self._request_json(f"{_PICTURES_URL}{sid}")
        if data is None:
            return False, None, "请求兽云祭服务失败，请稍后重试"
        code = data.get("code")
        if code == "20600":
            return True, data, "ok"
        if code == "20601":
            return False, None, "该 SID 暂无图片"
        return False, None, str(data.get("msg", "未知错误"))


@register(
    "astrbot_plugin_furry_maowu",
    "星辰OWO",
    "基于兽云祭 API 获取随机或指定的 Furry 毛图 / 兽兽插画",
    "1.1.0",
)
class FurryMaowuPlugin(Star):
    def __init__(self, context: Context):
        super().__init__(context)
        self.client = FoxtailClient()

    @filter.command("随机毛五")
    async def random_maowu(self, event: AstrMessageEvent):
        """随机获取一张兽图或毛毛照片或插画。"""
        ok, pic, msg = await self.client.get_random()
        if not ok or not pic:
            yield event.plain_result(msg)
            return
        async for result in self._reply_picture(event, str(pic.get("id", ""))):
            yield result

    @filter.command("来只")
    async def laizhi(self, event: AstrMessageEvent):
        """按数字 SID 或名称获取指定图片。用法：/来只 123 或 /来只 名称。"""
        arg = self._extract_arg(event.message_str, "来只")
        if not arg:
            yield event.plain_result(
                "请携带参数使用哦，例如：\n"
                "/来只 123 （按数字 SID）\n"
                "/来只 名称 （按名称搜索）",
            )
            return
        # 纯数字视为 SID，直接拉取；否则按名称模糊搜索。
        if arg.isdigit():
            async for result in self._reply_picture(event, arg):
                yield result
            return
        ok, pic, msg = await self.client.get_random(name=arg)
        if not ok or not pic:
            yield event.plain_result(msg)
            return
        async for result in self._reply_picture(event, str(pic.get("id", ""))):
            yield result

    @filter.command("来只毛")
    async def laizhi_mao(self, event: AstrMessageEvent):
        """随机或按名称获取一张毛毛照片。用法：/来只毛 或 /来只毛 名称。"""
        arg = self._extract_arg(event.message_str, "来只毛")
        if arg:
            ok, pic, msg = await self.client.get_random(pic_type="1", name=arg)
        else:
            ok, pic, msg = await self.client.get_random(pic_type="1")
        if not ok or not pic:
            yield event.plain_result(msg)
            return
        async for result in self._reply_picture(event, str(pic.get("id", ""))):
            yield result

    @filter.command("来只兽")
    async def laizhi_shou(self, event: AstrMessageEvent):
        """随机或按名称获取一张兽兽插画。用法：/来只兽 或 /来只兽 名称。"""
        arg = self._extract_arg(event.message_str, "来只兽")
        if arg:
            ok, pic, msg = await self.client.get_random(pic_type="2", name=arg)
        else:
            ok, pic, msg = await self.client.get_random(pic_type="2")
        if not ok or not pic:
            yield event.plain_result(msg)
            return
        async for result in self._reply_picture(event, str(pic.get("id", ""))):
            yield result

    @staticmethod
    def _extract_arg(message_str: str, command: str) -> str:
        """从消息中去掉指令名，返回去除首尾空白后的剩余参数。

        Args:
            message_str: 事件原始消息文本（不含唤醒前缀）。
            command: 当前指令名，如「来只毛」。

        Returns:
            指令后的参数；若仅有指令名则返回空字符串。
        """
        text = message_str.strip()
        # 兼容个别情况下消息仍携带唤醒前缀（如 /）的场景。
        if text.startswith("/"):
            text = text[1:].strip()
        if text == command:
            return ""
        if text.startswith(command):
            return text[len(command) :].strip()
        return text.strip()

    async def _reply_picture(self, event: AstrMessageEvent, sid: str):
        """根据 SID 拉取图片详情并发送图文消息链。"""
        if not sid:
            yield event.plain_result("图片 SID 解析失败，请稍后重试")
            return
        ok, detail, msg = await self.client.get_by_sid(sid)
        if not ok or not detail:
            yield event.plain_result(msg)
            return
        yield event.chain_result(self._build_chain(detail))

    @staticmethod
    def _build_chain(detail: dict) -> list:
        """根据图片详情构建回复消息链（文本信息 + 图片）。

        Args:
            detail: 拉取指定图片接口返回的详情字典。

        Returns:
            消息组件列表，包含名称 / SID / 留言 文本与图片组件。
        """
        name = detail.get("name", "未知")
        sid = detail.get("id", "未知")
        suggest = (detail.get("suggest") or "").strip()
        url = detail.get("url", "")
        chain: list = [
            Comp.Plain(f"名称：{name}\n"),
            Comp.Plain(f"SID：{sid}\n"),
        ]
        if suggest:
            chain.append(Comp.Plain(f"留言：{suggest}\n"))
        if url:
            chain.append(Comp.Image.fromURL(url))
        else:
            chain.append(Comp.Plain("（图片链接获取失败）"))
        return chain
